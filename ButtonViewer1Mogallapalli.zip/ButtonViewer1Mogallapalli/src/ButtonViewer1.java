import javax.swing.JFrame;
/**  
* Sabarish Mogallapalli - smogallapalli
* CIS171 27114
* Apr 20, 2022  
*/
public class ButtonViewer1 {
	public static void main(String[] args) {
		JFrame frame = new ButtonFrame1();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
